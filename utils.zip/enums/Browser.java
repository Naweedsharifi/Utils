package com.wbg.selenium.qa.enums;

public enum Browser {

	CHROME, FIREFOX, IE
}
